﻿namespace myMedical
{
	public class Model1
	{
		public string Text { get; set; }
	}
}
